# -*- encoding: utf-8 -*-
"""
@File    : __init__.py.py
@Time    : 2020/9/15 20:08
@Author  : hurui
@Email   : 18476856458@163.com
@Software: PyCharm
"""
from .facedetect import *